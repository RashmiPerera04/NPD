#!/usr/bin/env python3
import os
import sys
import hashlib
import json
import logging
import datetime
import psutil
import subprocess
import threading
import webbrowser
from time import sleep
from getpass import getpass
from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from flask_socketio import SocketIO
import secrets

# Configuration Files
CRED_FILE = "firewall_users.json"
RULES_FILE = "firewall_rules.json"
LOG_FILE = "firewall.log"
NETWORK_FILE = "network_adapters.json"

# Color Codes
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RESET = "\033[0m"

# Protocol Mappings
PROTOCOLS = {
    'http': ('tcp', 80),
    'https': ('tcp', 443),
    'ftp': ('tcp', 21),
    'ssh': ('tcp', 22),
    'telnet': ('tcp', 23),
    'icmp': ('icmp', None)
}

# Global State
current_user = None
firewall_active = True
ids_mode = True
flask_app = None
socketio = None
log_thread = None
web_server_running = False
IDS_IPS_LOG_FILE = "ids_ips.log"
ids_enabled = False
ips_enabled = False

# Initialize Flask for Web GUI
def create_flask_app():
    app = Flask(__name__)
    app.secret_key = secrets.token_hex(16)
    socketio = SocketIO(app, cors_allowed_origins="*")
    
    return app, socketio

# Set up logging
class LogHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.logs = []
        
    def emit(self, record):
        log_entry = self.format(record)
        self.logs.append(log_entry)
        if socketio:
            socketio.emit('log_update', {'log': log_entry})

log_handler = LogHandler()
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s | %(levelname)-8s | %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(),
        log_handler
    ]
)
logger = logging.getLogger()

# --- Utility Functions ---

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def validate_user(username, password):
    users = load_json(CRED_FILE, {})
    return users.get(username) == hash_password(password)

def log_event(msg, level="info"):
    if level == "info":
        logger.info(msg)
    elif level == "warn":
        logger.warning(msg)
    else:
        logger.error(msg)

def load_json(filename, default):
    if not os.path.exists(filename):
        with open(filename, "w") as f:
            json.dump(default, f)
    with open(filename) as f:
        return json.load(f)

def save_json(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=2)

def init_system():
    # Stop firewalld
    try:
        subprocess.run(["systemctl", "stop", "firewalld"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "firewalld"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        logger.warning(f"Could not disable firewalld: {e}")
    
    # Init files
    load_json(CRED_FILE, {"admin": hash_password("admin")})
    load_json(RULES_FILE, [])
    load_json(NETWORK_FILE, list(psutil.net_if_addrs().keys()))

def authenticate():
    global current_user
    for _ in range(3):
        username = input("Username: ")
        password = getpass("Password: ")
        users = load_json(CRED_FILE, {})
        if users.get(username) == hash_password(password):
            current_user = username
            log_event(f"Successful login: {username}", "info")
            return True
        else:
            log_event("Invalid credentials", "error")
    log_event("Too many failed login attempts", "error")
    sys.exit(1)

# --- Firewall Rule Management ---

def iptables_cmd(args):
    cmd = ["iptables"] + args
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.returncode, result.stdout.decode(), result.stderr.decode()

def apply_rule(rule):
    # Build iptables command
    args = []
    if rule["direction"] == "in":
        args += ["-A", "INPUT"]
    elif rule["direction"] == "out":
        args += ["-A", "OUTPUT"]
    else:
        # Both: apply twice
        r1 = rule.copy(); r1["direction"] = "in"
        r2 = rule.copy(); r2["direction"] = "out"
        apply_rule(r1); apply_rule(r2); return
    if rule.get("protocol"):
        args += ["-p", rule["protocol"]]
    if rule.get("source_ip"):
        args += ["-s", rule["source_ip"]]
    if rule.get("destination_ip"):
        args += ["-d", rule["destination_ip"]]
    if rule.get("port") and rule["protocol"] in ("tcp", "udp"):
        args += ["--dport", str(rule["port"])]
    if rule.get("interface"):
        if rule["direction"] == "in":
            args += ["-i", rule["interface"]]
        else:
            args += ["-o", rule["interface"]]
    action = "ACCEPT" if rule["action"] == "allow" else "DROP"
    args += ["-j", action]
    rc, out, err = iptables_cmd(args)
    if rc == 0:
        log_event(f"Applied rule: {rule['name']} ({rule['action']})", "info" if action == "ACCEPT" else "error")
    else:
        log_event(f"Failed to apply rule: {err}", "error")

def flush_rules():
    iptables_cmd(["-F"])

def reapply_all_rules():
    flush_rules()
    rules = load_json(RULES_FILE, [])
    for rule in rules:
        apply_rule(rule)

def delete_rule(index):
    rules = load_json(RULES_FILE, [])
    if 0 <= index < len(rules):
        del rules[index]
        save_json(RULES_FILE, rules)
        reapply_all_rules()
        log_event("Rule deleted", "warn")
        return True
    return False

# --- CLI Functions ---

def manage_rules():
    while True:
        print(f"\n{CYAN}Rule Management{RESET}")
        print("1 - Add Rule")
        print("2 - View Rules")
        print("3 - Manage Order")
        print("4 - Delete Rule")
        print("5 - Exit")
        sel = input("Select option: ")
        if sel == "1":
            rule = {}
            rule["name"] = input("Rule Name: ")
            rule["source_ip"] = input("Source IP (empty=any): ") or None
            rule["destination_ip"] = input("Destination IP/Domain (empty=any): ") or None
            print("\nProtocols: 1-http 2-https 3-ftp 4-ssh 5-telnet 6-icmp 7-custom")
            psel = input("Select protocol: ")
            if psel in "123456":
                proto = list(PROTOCOLS.keys())[int(psel)-1]
                rule["protocol"] = PROTOCOLS[proto][0]
                rule["port"] = PROTOCOLS[proto][1]
            else:
                rule["protocol"] = input("Protocol: ")
                rule["port"] = input("Port (empty=any): ") or None
                if rule["port"]: rule["port"] = int(rule["port"])
            print("Direction: 1-In 2-Out 3-Both")
            dsel = input("Select direction: ")
            rule["direction"] = ["in", "out", "both"][int(dsel)-1]
            rule["action"] = "allow" if input("1-Allow 2-Deny: ") == "1" else "deny"
            adapters = load_json(NETWORK_FILE, [])
            print("Available interfaces:", ", ".join(adapters))
            rule["interface"] = input("Interface (empty=all): ") or None
            rules = load_json(RULES_FILE, [])
            rules.append(rule)
            save_json(RULES_FILE, rules)
            apply_rule(rule)
            log_event(f"{current_user} added rule '{rule['name']}' ({rule['action']})", "info" if rule["action"]=="allow" else "error")
        elif sel == "2":
            rules = load_json(RULES_FILE, [])
            for i, rule in enumerate(rules, 1):
                color = GREEN if rule["action"] == "allow" else RED
                print(f"{i}. {color}{rule['name']} ({rule['action']}){RESET}")
                print(f"   Src: {rule.get('source_ip','any')}, Dst: {rule.get('destination_ip','any')}, Proto: {rule.get('protocol','any')}, Port: {rule.get('port','any')}, Dir: {rule['direction']}, Iface: {rule.get('interface','any')}")
        elif sel == "3":
            rules = load_json(RULES_FILE, [])
            for i, rule in enumerate(rules, 1):
                print(f"{i}. {rule['name']}")
            idx = int(input("Rule number to move: ")) - 1
            direction = input("(u)p or (d)own? ")
            if direction == "u" and idx > 0:
                rules[idx], rules[idx-1] = rules[idx-1], rules[idx]
            elif direction == "d" and idx < len(rules)-1:
                rules[idx], rules[idx+1] = rules[idx+1], rules[idx]
            save_json(RULES_FILE, rules)
            reapply_all_rules()
        elif sel == "4":
            rules = load_json(RULES_FILE, [])
            for i, rule in enumerate(rules, 1):
                print(f"{i}. {rule['name']}")
            idx = int(input("Rule number to delete: ")) - 1
            delete_rule(idx)
        elif sel == "5":
            return

def system_security():
    if current_user != "admin":
        print(f"{RED}Permission denied!{RESET}")
        return
    while True:
        print(f"\n{YELLOW}System Security{RESET}")
        print("1 - Add User")
        print("2 - View Users")
        print("3 - Change Password")
        print("4 - Delete User")
        print("5 - Exit")
        sel = input("Select option: ")
        users = load_json(CRED_FILE, {})
        if sel == "1":
            uname = input("New username: ")
            pw = getpass("Password: ")
            if uname in users:
                print("User exists.")
            else:
                users[uname] = hash_password(pw)
                save_json(CRED_FILE, users)
                log_event(f"User {uname} added", "warn")
        elif sel == "2":
            print("Users: " + ", ".join(users.keys()))
        elif sel == "3":
            print("Users: " + ", ".join(users.keys()))
            uname = input("Change password for: ")
            if uname not in users:
                print("No such user.")
            else:
                pw = getpass("New password: ")
                users[uname] = hash_password(pw)
                save_json(CRED_FILE, users)
                log_event(f"Password changed for {uname}", "warn")
        elif sel == "4":
            print("Users: " + ", ".join(users.keys()))
            uname = input("Delete user: ")
            if uname == "admin":
                print("Cannot delete admin.")
            elif uname in users:
                del users[uname]
                save_json(CRED_FILE, users)
                log_event(f"User {uname} deleted", "warn")
        elif sel == "5":
            return
        






        #### IDS/IPS Management ###




def ids_ips_management():
    global ids_enabled, ips_enabled
    
    while True:
        print(f"\n{CYAN}IDS/IPS Management{RESET}")
        print("1 - Switch IDS/IPS Mode")
        print("2 - View & Manage Logs")
        print("3 - Return to Main Menu")
        choice = input("Select option: ")
        
        if choice == "1":
            print("\n1 - Enable IDS (Detection Only)")
            print("2 - Enable IPS (Prevention)")
            print("3 - Disable Both")
            mode = input("Select mode: ")
            
            if mode == "1":
                ids_enabled = True
                ips_enabled = False
                log_event("IDS enabled - Detection mode active", "info")
            elif mode == "2":
                ips_enabled = True
                ids_enabled = False 
                log_event("IPS enabled - Prevention mode active", "info")
            elif mode == "3":
                ids_enabled = False
                ips_enabled = False
                log_event("IDS/IPS disabled", "warn")
            else:
                print(f"{RED}Invalid selection{RESET}")
            
            status = "IDS: " + ("ON" if ids_enabled else "OFF") + " | IPS: " + ("ON" if ips_enabled else "OFF")
            print(f"\n{YELLOW}Current Status: {status}{RESET}")
        
        elif choice == "2":
            try:
                with open(IDS_IPS_LOG_FILE, "r") as f:
                    logs = f.readlines()
                
                if not logs:
                    print(f"{YELLOW}No IDS/IPS events logged{RESET}")
                    continue
                
                print(f"\n{GREEN}IDS/IPS Event Log:{RESET}")
                for idx, log in enumerate(logs, 1):
                    print(f"{idx}. {log.strip()}")
                
                selected = input("\nEnter event number to handle (or 'q' to quit): ")
                if selected.lower() != 'q' and selected.isdigit():
                    index = int(selected) - 1
                    if 0 <= index < len(logs):
                        entry = json.loads(logs[index].split(" - ")[-1])
                        print(f"\n{YELLOW}Event Details:{RESET}")
                        print(f"Timestamp: {entry['timestamp']}")
                        print(f"Source IP: {entry['source_ip']}")
                        print(f"Destination IP: {entry['destination_ip']}") 
                        print(f"Protocol: {entry['protocol']}")
                        print(f"Port: {entry['port']}")
                        
                        action = input("\nHandle traffic (1-Allow, 2-Deny, 3-Ignore): ")
                        if action == "1":
                            rule = {
                                "name": f"Allowed {entry['source_ip']}",
                                "source_ip": entry['source_ip'],
                                "protocol": entry['protocol'],
                                "port": entry['port'],
                                "direction": "in",
                                "action": "allow",
                                "interface": None
                            }
                            apply_rule(rule)
                            log_event(f"Allowed traffic from {entry['source_ip']} based on IDS/IPS event", "info")
                        elif action == "2":
                            rule = {
                                "name": f"Blocked {entry['source_ip']}",
                                "source_ip": entry['source_ip'],
                                "protocol": entry['protocol'],
                                "port": entry['port'],
                                "direction": "in",
                                "action": "deny",
                                "interface": None
                            }
                            apply_rule(rule)
                            log_event(f"Blocked traffic from {entry['source_ip']} based on IDS/IPS event", "warn")
                            
                        # Mark entry as handled
                        logs[index] = logs[index].strip() + " [HANDLED]\n"
                        with open(IDS_IPS_LOG_FILE, "w") as f:
                            f.writelines(logs)
                    else:
                        print(f"{RED}Invalid event number{RESET}")
            except Exception as e:
                print(f"{RED}Error reading logs: {e}{RESET}")
        
        elif choice == "3":
            return
        else:
            print(f"{RED}Invalid choice{RESET}")

def show_logs():
    try:
        with open(LOG_FILE, "r") as f:
            for line in f.readlines():
                if "INFO" in line:
                    print(f"{GREEN}{line.strip()}{RESET}")
                elif "WARNING" in line:
                    print(f"{YELLOW}{line.strip()}{RESET}")
                else:
                    print(f"{RED}{line.strip()}{RESET}")
    except Exception as e:
        print(f"Error reading logs: {e}")

def firewall_manage():
    global firewall_active
    while True:
        print(f"\n{CYAN}Firewall Manage{RESET}")
        print("1 - Start")
        print("2 - Status")
        print("3 - Restart")
        print("4 - Stop")
        print("5 - Exit")
        sel = input("Select: ")
        if sel == "1":
            firewall_active = True
            reapply_all_rules()
            log_event("Firewall started", "info")
        elif sel == "2":
            print("Active" if firewall_active else "Inactive")
        elif sel == "3":
            reapply_all_rules()
            log_event("Firewall restarted", "info")
        elif sel == "4":
            flush_rules()
            firewall_active = False
            log_event("Firewall stopped", "warn")
        elif sel == "5":
            return

def network_manager():
    while True:
        print(f"\n{CYAN}Network Manager{RESET}")
        print("1 - Add Adapter")
        print("2 - Show Adapters")
        print("3 - Remove Adapter")
        print("4 - Exit")
        sel = input("Select: ")
        adapters = load_json(NETWORK_FILE, [])
        if sel == "1":
            all_adapters = list(psutil.net_if_addrs().keys())
            print("Available:", ", ".join([a for a in all_adapters if a not in adapters]))
            iface = input("Add interface: ")
            if iface in all_adapters and iface not in adapters:
                adapters.append(iface)
                save_json(NETWORK_FILE, adapters)
                log_event(f"Added network adapter {iface}", "info")
        elif sel == "2":
            print("Adapters:", ", ".join(adapters))
        elif sel == "3":
            print("Adapters:", ", ".join(adapters))
            iface = input("Remove interface: ")
            if iface in adapters:
                adapters.remove(iface)
                save_json(NETWORK_FILE, adapters)
                log_event(f"Removed network adapter {iface}", "warn")
        elif sel == "4":
            return

# --- Web GUI Functions ---

def setup_web_gui(app, socketio):
    @app.route('/')
    def home():
        if 'username' not in session:
            return redirect(url_for('login'))
        return render_template('index.html', username=session['username'])
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            if validate_user(username, password):
                session['username'] = username
                log_event(f"Web login: {username}", "info")
                return redirect(url_for('home'))
            else:
                flash('Invalid credentials')
                log_event(f"Failed web login attempt: {username}", "error")
        return render_template('login.html')
    
    @app.route('/logout')
    def logout():
        log_event(f"Web logout: {session.get('username', 'unknown')}", "info")
        session.pop('username', None)
        return redirect(url_for('login'))
    
    @app.route('/api/rules', methods=['GET'])
    def get_rules():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return jsonify(load_json(RULES_FILE, []))
    
    @app.route('/api/rules', methods=['POST'])
    def add_rule():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        rule = request.json
        rules = load_json(RULES_FILE, [])
        rules.append(rule)
        save_json(RULES_FILE, rules)
        apply_rule(rule)
        log_event(f"{session['username']} added rule '{rule['name']}' ({rule['action']})", 
                  "info" if rule["action"]=="allow" else "error")
        return jsonify({"status": "success"})
    
    @app.route('/api/rules/<int:index>', methods=['DELETE'])
    def remove_rule(index):
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        if delete_rule(index):
            return jsonify({"status": "success"})
        return jsonify({"error": "Rule not found"}), 404
    
    @app.route('/api/rules/reorder', methods=['POST'])
    def reorder_rules():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        data = request.json
        index = data['index']
        direction = data['direction']
        
        rules = load_json(RULES_FILE, [])
        if direction == 'up' and index > 0:
            rules[index], rules[index-1] = rules[index-1], rules[index]
        elif direction == 'down' and index < len(rules)-1:
            rules[index], rules[index+1] = rules[index+1], rules[index]
        else:
            return jsonify({"error": "Invalid move"}), 400
            
        save_json(RULES_FILE, rules)
        reapply_all_rules()
        log_event(f"{session['username']} reordered rules", "info")
        return jsonify({"status": "success"})
    
    @app.route('/api/users', methods=['GET'])
    def get_users():
        if 'username' not in session or session['username'] != 'admin':
            return jsonify({"error": "Unauthorized"}), 401
        return jsonify(list(load_json(CRED_FILE, {}).keys()))
    
    @app.route('/api/users', methods=['POST'])
    def add_user():
        if 'username' not in session or session['username'] != 'admin':
            return jsonify({"error": "Unauthorized"}), 401
        data = request.json
        users = load_json(CRED_FILE, {})
        users[data['username']] = hash_password(data['password'])
        save_json(CRED_FILE, users)
        log_event(f"User {data['username']} added by {session['username']}", "warn")
        return jsonify({"status": "success"})
    
    @app.route('/api/users/<username>', methods=['DELETE'])
    def delete_user(username):
        if 'username' not in session or session['username'] != 'admin':
            return jsonify({"error": "Unauthorized"}), 401
        if username == 'admin':
            return jsonify({"error": "Cannot delete admin"}), 400
            
        users = load_json(CRED_FILE, {})
        if username in users:
            del users[username]
            save_json(CRED_FILE, users)
            log_event(f"User {username} deleted by {session['username']}", "warn")
            return jsonify({"status": "success"})
        return jsonify({"error": "User not found"}), 404
    
    @app.route('/api/users/<username>/password', methods=['PUT'])
    def change_password(username):
        if 'username' not in session or session['username'] != 'admin':
            return jsonify({"error": "Unauthorized"}), 401
            
        data = request.json
        users = load_json(CRED_FILE, {})
        if username in users:
            users[username] = hash_password(data['password'])
            save_json(CRED_FILE, users)
            log_event(f"Password changed for {username} by {session['username']}", "warn")
            return jsonify({"status": "success"})
        return jsonify({"error": "User not found"}), 404
    
    @app.route('/api/firewall/status', methods=['GET'])
    def get_firewall_status():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return jsonify({"active": firewall_active})
    
    @app.route('/api/firewall/start', methods=['POST'])
    def start_firewall():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        global firewall_active
        firewall_active = True
        reapply_all_rules()
        log_event(f"Firewall started by {session['username']}", "info")
        return jsonify({"status": "success"})
    
    @app.route('/api/firewall/stop', methods=['POST'])
    def stop_firewall():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        global firewall_active
        flush_rules()
        firewall_active = False
        log_event(f"Firewall stopped by {session['username']}", "warn")
        return jsonify({"status": "success"})
    
    @app.route('/api/firewall/restart', methods=['POST'])
    def restart_firewall():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        reapply_all_rules()
        log_event(f"Firewall restarted by {session['username']}", "info")
        return jsonify({"status": "success"})
    
    @app.route('/api/adapters', methods=['GET'])
    def get_adapters():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return jsonify(load_json(NETWORK_FILE, []))
    
    @app.route('/api/adapters/available', methods=['GET'])
    def get_available_adapters():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        current = load_json(NETWORK_FILE, [])
        all_adapters = list(psutil.net_if_addrs().keys())
        return jsonify([a for a in all_adapters if a not in current])
    
    @app.route('/api/adapters', methods=['POST'])
    def add_adapter():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        data = request.json
        adapters = load_json(NETWORK_FILE, [])
        all_adapters = list(psutil.net_if_addrs().keys())
        if data['adapter'] in all_adapters and data['adapter'] not in adapters:
            adapters.append(data['adapter'])
            save_json(NETWORK_FILE, adapters)
            log_event(f"Added network adapter {data['adapter']} by {session['username']}", "info")
            return jsonify({"status": "success"})
        return jsonify({"error": "Invalid adapter"}), 400
    
    @app.route('/api/adapters/<adapter>', methods=['DELETE'])
    def remove_adapter(adapter):
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        adapters = load_json(NETWORK_FILE, [])
        if adapter in adapters:
            adapters.remove(adapter)
            save_json(NETWORK_FILE, adapters)
            log_event(f"Removed network adapter {adapter} by {session['username']}", "warn")
            return jsonify({"status": "success"})
        return jsonify({"error": "Adapter not found"}), 404
    
    @app.route('/api/logs', methods=['GET'])
    def get_logs():
        if 'username' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        try:
            with open(LOG_FILE, "r") as f:
                logs = f.readlines()
            return jsonify(logs)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    
    @socketio.on('connect')
    def handle_connect():
        if 'username' not in session:
            return False
        socketio.emit('log_history', {'logs': log_handler.logs})
    
    def emit_logs():
        while True:
            try:
                with open(LOG_FILE, "r") as f:
                    logs = f.readlines()
                socketio.emit('log_update', {'logs': logs[-10:]})
                sleep(1)
            except Exception as e:
                print(f"Error in log thread: {e}")
                sleep(5)
    
    global log_thread
    if log_thread is None:
        log_thread = threading.Thread(target=emit_logs)
        log_thread.daemon = True
        log_thread.start()

def create_templates_folder():
    """Create templates folder and HTML files for the web interface"""
    os.makedirs('templates', exist_ok=True)
    
    # Create login.html
    with open('templates/login.html', 'w') as f:
        f.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RapyDe Guard Firewall - Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 40px;
            width: 350px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .flash-message {
            background-color: #f44336;
            color: white;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>RapyDe Guard Firewall</h1>
        
        {% with messages = get_flashed_messages() %}
        {% if messages %}
        <div class="flash-message">
            {{ messages[0] }}
        </div>
        {% endif %}
        {% endwith %}
        
        <form method="post" action="/login">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="submit-btn">Login</button>
        </form>
    </div>
</body>
</html>
        ''')
    
    # Create index.html
    with open('templates/index.html', 'w') as f:
        f.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RapyDe Guard Firewall</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.0.1/socket.io.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            background-color: #f5f5f5;
        }
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding: 20px 0;
            display: flex;
            flex-direction: column;
        }
        .sidebar h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
            padding: 0 20px;
        }
        .sidebar-menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
            flex-grow: 1;
        }
        .sidebar-menu li {
            padding: 0;
            margin-bottom: 5px;
        }
        .sidebar-menu button {
            width: 100%;
            padding: 15px 20px;
            text-align: left;
            background-color: transparent;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
        }
        .sidebar-menu button:hover {
            background-color: #444;
        }
        .sidebar-menu button.active {
            background-color: #4CAF50;
        }
        .sidebar-menu button i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .sidebar-menu button.exit {
            background-color: #f44336;
            position: relative;
            bottom: 0;
            margin-top: auto;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
            position: relative;
        }
        .header {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        .header .user-info {
            display: flex;
            align-items: center;
        }
        .header .username {
            margin-right: 15px;
            font-weight: bold;
        }
        .logout-btn {
            padding: 8px 15px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .section {
            display: none;
            animation: fadeIn 0.3s;
        }
        .section.active {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        h2 {
            color: #333;
            margin-top: 0;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }
        button.primary {
            background-color: #4CAF50;
            color: white;
        }
        button.primary:hover {
            background-color: #45a049;
        }
        button.secondary {
            background-color: #2196F3;
            color: white;
        }
        button.secondary:hover {
            background-color: #0b7dda;
        }
        button.danger {
            background-color: #f44336;
            color: white;
        }
        button.danger:hover {
            background-color: #d32f2f;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .welcome-message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: black;
            color: #7CFC00;
            padding: 20px 30px;
            border-radius: 8px;
            z-index: 1000;
        }
        .log-container {
            background-color: #333;
            color: #ddd;
            padding: 15px;
            font-family: monospace;
            height: 500px;
            overflow-y: auto;
            border-radius: 4px;
        }
        .log-entry {
            margin-bottom: 5px;
            line-height: 1.4;
        }
        .log-info {
            color: #4CAF50;
        }
        .log-warning {
            color: #FFC107;
        }
        .log-error {
            color: #f44336;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            border-radius: 8px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .flex-between {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="welcome-message" id="welcomeMessage">
        <h2>Welcome {{ username }} to RapyDe Guard Firewall</h2>
    </div>

    <div class="sidebar">
        <h1>RapyDe Guard Firewall</h1>
        <ul class="sidebar-menu">
            <li><button id="btn-manage-rules" class="active"><i class="fas fa-shield-alt"></i> Manage Rules</button></li>
            <li><button id="btn-system-security"><i class="fas fa-users-cog"></i> System Security</button></li>
            <li><button id="btn-ids-ips"><i class="fas fa-search"></i> IDS/IPS Management</button></li>
            <li><button id="btn-system-logs"><i class="fas fa-clipboard-list"></i> System Logs</button></li>
            <li><button id="btn-firewall-manage"><i class="fas fa-fire"></i> Firewall Manage</button></li>
            <li><button id="btn-network-adapters"><i class="fas fa-network-wired"></i> Network Adapters</button></li>
            <li><button class="exit" id="btn-exit"><i class="fas fa-sign-out-alt"></i> Exit</button></li>
        </ul>
    </div>

    <div class="content">
        <div class="header">
            <div class="user-info">
                <span class="username">{{ username }}</span>
                <a href="/logout" class="logout-btn">Logout</a>
            </div>
        </div>

        <!-- Manage Rules Section -->
        <div class="section active" id="section-manage-rules">
            <div class="card">
                <div class="flex-between">
                    <h2>Manage Firewall Rules</h2>
                    <button class="primary" id="btn-add-rule">Add Rule</button>
                </div>
                <div id="rules-table-container">
                    <table id="rules-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Source</th>
                                <th>Destination</th>
                                <th>Protocol</th>
                                <th>Port</th>
                                <th>Direction</th>
                                <th>Action</th>
                                <th>Interface</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody id="rules-tbody">
                            <!-- Rules will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- System Security Section -->
        <div class="section" id="section-system-security">
            <div class="card">
                <div class="flex-between">
                    <h2>User Management</h2>
                    <button class="primary" id="btn-add-user">Add User</button>
                </div>
                <table id="users-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="users-tbody">
                        <!-- Users will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- IDS/IPS Management Section -->
        <div class="section" id="section-ids-ips">
            <div class="card">
                <h2>IDS/IPS Management</h2>
                <p>IDS/IPS functionality is not available in GUI mode at this time. Please use CLI mode for this feature.</p>
            </div>
        </div>

        <!-- System Logs Section -->
        <div class="section" id="section-system-logs">
            <div class="card">
                <h2>System Logs</h2>
                <div class="log-container" id="logs-container">
                    <!-- Logs will be loaded here -->
                </div>
            </div>
        </div>

        <!-- Firewall Manage Section -->
        <div class="section" id="section-firewall-manage">
            <div class="card">
                <h2>Firewall Management</h2>
                <div class="firewall-status-container">
                    <p>Current Status: <span id="firewall-status" class="status">Checking...</span></p>
                    <div class="firewall-actions">
                        <button class="primary" id="btn-start-firewall">Start</button>
                        <button class="secondary" id="btn-restart-firewall">Restart</button>
                        <button class="danger" id="btn-stop-firewall">Stop</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Network Adapters Section -->
        <div class="section" id="section-network-adapters">
            <div class="card">
                <div class="flex-between">
                    <h2>Network Adapters</h2>
                    <button class="primary" id="btn-add-adapter">Add Adapter</button>
                </div>
                <table id="adapters-table">
                    <thead>
                        <tr>
                            <th>Adapter Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="adapters-tbody">
                        <!-- Adapters will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Rule Modal -->
    <div id="add-rule-modal" class="modal">
        <div class="modal-content">
            <span class="close" id="close-add-rule">&times;</span>
            <h2>Add New Rule</h2>
            <form id="add-rule-form">
                <div class="form-group">
                    <label for="rule-name">Rule Name</label>
                    <input type="text" id="rule-name" required>
                </div>
                <div class="form-group">
                    <label for="source-ip">Source IP (empty for any)</label>
                    <input type="text" id="source-ip">
                </div>
                <div class="form-group">
                    <label for="destination-ip">Destination IP/Domain (empty for any)</label>
                    <input type="text" id="destination-ip">
                </div>
                <div class="form-group">
                    <label for="protocol">Protocol</label>
                    <select id="protocol">
                        <option value="http">HTTP</option>
                        <option value="https">HTTPS</option>
                        <option value="ftp">FTP</option>
                        <option value="ssh">SSH</option>
                        <option value="telnet">Telnet</option>
                        <option value="icmp">ICMP</option>
                        <option value="custom">Custom</option>
                    </select>
                </div>
                <div class="form-group" id="custom-protocol-group" style="display:none;">
                    <label for="custom-protocol">Custom Protocol</label>
                    <input type="text" id="custom-protocol">
                </div>
                <div class="form-group" id="port-group">
                    <label for="port">Port (empty for any)</label>
                    <input type="number" id="port">
                </div>
                <div class="form-group">
                    <label for="direction">Direction</label>
                    <select id="direction">
                        <option value="in">Incoming (outside to inside)</option>
                        <option value="out">Outgoing (inside to outside)</option>
                        <option value="both">Both</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="action">Action</label>
                    <select id="action">
                        <option value="allow">Allow</option>
                        <option value="deny">Deny</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="interface">Interface (empty for all)</label>
                    <select id="interface">
                        <option value="">All Interfaces</option>
                        <!-- Interfaces will be loaded here -->
                    </select>
                </div>
                <button type="submit" class="primary">Add Rule</button>
            </form>
        </div>
    </div>

    <!-- Add User Modal -->
    <div id="add-user-modal" class="modal">
        <div class="modal-content">
            <span class="close" id="close-add-user">&times;</span>
            <h2>Add New User</h2>
            <form id="add-user-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="new-username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="new-password" required>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Confirm Password</label>
                    <input type="password" id="confirm-password" required>
                </div>
                <button type="submit" class="primary">Add User</button>
            </form>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div id="change-password-modal" class="modal">
        <div class="modal-content">
            <span class="close" id="close-change-password">&times;</span>
            <h2>Change Password</h2>
            <form id="change-password-form">
                <input type="hidden" id="change-password-username">
                <div class="form-group">
                    <label for="new-password">New Password</label>
                    <input type="password" id="change-new-password" required>
                </div>
                <div class="form-group">
                    <label for="confirm-new-password">Confirm New Password</label>
                    <input type="password" id="confirm-new-password" required>
                </div>
                <button type="submit" class="primary">Change Password</button>
            </form>
        </div>
    </div>

    <!-- Add Adapter Modal -->
    <div id="add-adapter-modal" class="modal">
        <div class="modal-content">
            <span class="close" id="close-add-adapter">&times;</span>
            <h2>Add Network Adapter</h2>
            <form id="add-adapter-form">
                <div class="form-group">
                    <label for="adapter">Available Adapters</label>
                    <select id="adapter-select">
                        <!-- Available adapters will be loaded here -->
                    </select>
                </div>
                <button type="submit" class="primary">Add Adapter</button>
            </form>
        </div>
    </div>

    <script>
        // Socket.io connection
        const socket = io();
        
        // DOM Elements
        const welcomeMessage = document.getElementById('welcomeMessage');
        const menuButtons = document.querySelectorAll('.sidebar-menu button');
        const sections = document.querySelectorAll('.section');
        
        // Show welcome message for 3 seconds
        setTimeout(() => {
            welcomeMessage.style.display = 'none';
        }, 3000);
        
        // Menu buttons click handlers
        menuButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetId = this.id.replace('btn-', 'section-');
                
                // Exit button special handling
                if (this.id === 'btn-exit') {
                    handleExit();
                    return;
                }
                
                // Remove active class from all buttons and sections
                menuButtons.forEach(btn => btn.classList.remove('active'));
                sections.forEach(section => section.classList.remove('active'));
                
                // Add active class to clicked button and target section
                this.classList.add('active');
                document.getElementById(targetId).classList.add('active');
                
                // Load section data
                if (targetId === 'section-manage-rules') loadRules();
                if (targetId === 'section-system-security') loadUsers();
                if (targetId === 'section-system-logs') loadLogs();
                if (targetId === 'section-firewall-manage') loadFirewallStatus();
                if (targetId === 'section-network-adapters') loadAdapters();
            });
        });
        
        // Exit handler
        function handleExit() {
            document.body.innerHTML = `
                <div style="height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; background-color: #333; color: white;">
                    <h1 style="font-size: 3rem; margin-bottom: 2rem;">RapyDe Guard Firewall</h1>
                    <p style="font-size: 1.5rem; margin-bottom: 2rem;">Thank you for using RapyDe Guard Firewall!</p>
                    <p style="font-size: 1.2rem;">The GUI interface has been closed. You can return to the CLI mode.</p>
                    <a href="/" style="margin-top: 2rem; padding: 1rem 2rem; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px;">Return to Login</a>
                </div>
            `;
        }
        
        // Modals
        const addRuleModal = document.getElementById('add-rule-modal');
        const addUserModal = document.getElementById('add-user-modal');
        const changePasswordModal = document.getElementById('change-password-modal');
        const addAdapterModal = document.getElementById('add-adapter-modal');
        
        // Close modal buttons
        document.getElementById('close-add-rule').onclick = () => addRuleModal.style.display = 'none';
        document.getElementById('close-add-user').onclick = () => addUserModal.style.display = 'none';
        document.getElementById('close-change-password').onclick = () => changePasswordModal.style.display = 'none';
        document.getElementById('close-add-adapter').onclick = () => addAdapterModal.style.display = 'none';
        
        // Open modal buttons
        document.getElementById('btn-add-rule').onclick = () => {
            loadInterfacesForRuleForm();
            addRuleModal.style.display = 'block';
        };
        document.getElementById('btn-add-user').onclick = () => {
            addUserModal.style.display = 'block';
        };
        document.getElementById('btn-add-adapter').onclick = () => {
            loadAvailableAdapters();
            addAdapterModal.style.display = 'block';
        };
        
        // Close modals when clicking outside
        window.onclick = (event) => {
            if (event.target === addRuleModal) addRuleModal.style.display = 'none';
            if (event.target === addUserModal) addUserModal.style.display = 'none';
            if (event.target === changePasswordModal) changePasswordModal.style.display = 'none';
            if (event.target === addAdapterModal) addAdapterModal.style.display = 'none';
        };
        
        // Protocol dropdown change handler
        document.getElementById('protocol').addEventListener('change', function() {
            const customProtocolGroup = document.getElementById('custom-protocol-group');
            const portGroup = document.getElementById('port-group');
            
            if (this.value === 'custom') {
                customProtocolGroup.style.display = 'block';
                portGroup.style.display = 'block';
            } else {
                customProtocolGroup.style.display = 'none';
                
                // Hide port group for ICMP
                if (this.value === 'icmp') {
                    portGroup.style.display = 'none';
                } else {
                    portGroup.style.display = 'block';
                    // Set default port based on protocol
                    const ports = {
                        'http': 80,
                        'https': 443,
                        'ftp': 21,
                        'ssh': 22,
                        'telnet': 23
                    };
                    document.getElementById('port').value = ports[this.value] || '';
                }
            }
        });
        
        // Form submissions
        document.getElementById('add-rule-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('rule-name').value;
            const sourceIp = document.getElementById('source-ip').value || null;
            const destinationIp = document.getElementById('destination-ip').value || null;
            const protocol = document.getElementById('protocol').value;
            const direction = document.getElementById('direction').value;
            const action = document.getElementById('action').value;
            const interfaceVal = document.getElementById('interface').value || null;
            
            let finalProtocol, port;
            
            if (protocol === 'custom') {
                finalProtocol = document.getElementById('custom-protocol').value;
                port = document.getElementById('port').value ? parseInt(document.getElementById('port').value) : null;
            } else {
                // Get protocol/port from predefined mappings
                const protocolMap = {
                    'http': ['tcp', 80],
                    'https': ['tcp', 443],
                    'ftp': ['tcp', 21],
                    'ssh': ['tcp', 22],
                    'telnet': ['tcp', 23],
                    'icmp': ['icmp', null]
                };
                finalProtocol = protocolMap[protocol][0];
                port = protocolMap[protocol][1];
            }
            
            // Create rule object
            const rule = {
                name: name,
                source_ip: sourceIp,
                destination_ip: destinationIp,
                protocol: finalProtocol,
                port: port,
                direction: direction,
                action: action,
                interface: interfaceVal
            };
            
            // Submit rule to API
            fetch('/api/rules', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(rule)
            })
            .then(response => response.json())
            .then(data => {
                addRuleModal.style.display = 'none';
                document.getElementById('add-rule-form').reset();
                loadRules();
            })
            .catch(error => console.error('Error adding rule:', error));
        });
        
        document.getElementById('add-user-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('new-username').value;
            const password = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            fetch('/api/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: username,
                    password: password
                })
            })
            .then(response => response.json())
            .then(data => {
                addUserModal.style.display = 'none';
                document.getElementById('add-user-form').reset();
                loadUsers();
            })
            .catch(error => console.error('Error adding user:', error));
        });
        
        document.getElementById('change-password-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('change-password-username').value;
            const newPassword = document.getElementById('change-new-password').value;
            const confirmNewPassword = document.getElementById('confirm-new-password').value;
            
            if (newPassword !== confirmNewPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            fetch(`/api/users/${username}/password`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    password: newPassword
                })
            })
            .then(response => response.json())
            .then(data => {
                changePasswordModal.style.display = 'none';
                document.getElementById('change-password-form').reset();
                alert('Password changed successfully!');
            })
            .catch(error => console.error('Error changing password:', error));
        });
        
        document.getElementById('add-adapter-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const adapter = document.getElementById('adapter-select').value;
            
            fetch('/api/adapters', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    adapter: adapter
                })
            })
            .then(response => response.json())
            .then(data => {
                addAdapterModal.style.display = 'none';
                loadAdapters();
            })
            .catch(error => console.error('Error adding adapter:', error));
        });
        
        // Firewall action buttons
        document.getElementById('btn-start-firewall').addEventListener('click', function() {
            fetch('/api/firewall/start', { method: 'POST' })
                .then(response => response.json())
                .then(data => loadFirewallStatus())
                .catch(error => console.error('Error starting firewall:', error));
        });
        
        document.getElementById('btn-restart-firewall').addEventListener('click', function() {
            fetch('/api/firewall/restart', { method: 'POST' })
                .then(response => response.json())
                .then(data => loadFirewallStatus())
                .catch(error => console.error('Error restarting firewall:', error));
        });
        
        document.getElementById('btn-stop-firewall').addEventListener('click', function() {
            fetch('/api/firewall/stop', { method: 'POST' })
                .then(response => response.json())
                .then(data => loadFirewallStatus())
                .catch(error => console.error('Error stopping firewall:', error));
        });
        
        // Data loading functions
        function loadRules() {
            fetch('/api/rules')
                .then(response => response.json())
                .then(rules => {
                    const tbody = document.getElementById('rules-tbody');
                    tbody.innerHTML = '';
                    
                    rules.forEach((rule, index) => {
                        const row = document.createElement('tr');
                        
                        row.innerHTML = `
                            <td>${rule.name}</td>
                            <td>${rule.source_ip || 'any'}</td>
                            <td>${rule.destination_ip || 'any'}</td>
                            <td>${rule.protocol}</td>
                            <td>${rule.port || 'any'}</td>
                            <td>${rule.direction}</td>
                            <td style="color: ${rule.action === 'allow' ? 'green' : 'red'}">${rule.action}</td>
                            <td>${rule.interface || 'any'}</td>
                            <td>
                                <button class="danger" onclick="deleteRule(${index})">Delete</button>
                                <button class="secondary" onclick="moveRule(${index}, 'up')">Move Up</button>
                                <button class="secondary" onclick="moveRule(${index}, 'down')">Move Down</button>
                            </td>
                        `;
                        
                        tbody.appendChild(row);
                    });
                })
                .catch(error => console.error('Error loading rules:', error));
        }
        
        function loadUsers() {
            fetch('/api/users')
                .then(response => response.json())
                .then(users => {
                    const tbody = document.getElementById('users-tbody');
                    tbody.innerHTML = '';
                    
                    users.forEach(username => {
                        const row = document.createElement('tr');
                        
                        row.innerHTML = `
                            <td>${username}</td>
                            <td>
                                <button class="secondary" onclick="changePassword('${username}')">Change Password</button>
                                ${username !== 'admin' ? `<button class="danger" onclick="deleteUser('${username}')">Delete</button>` : ''}
                            </td>
                        `;
                        
                        tbody.appendChild(row);
                    });
                })
                .catch(error => console.error('Error loading users:', error));
        }
        
        function loadLogs() {
            const logsContainer = document.getElementById('logs-container');
            logsContainer.innerHTML = '';
            
            // We'll use socket.io to get real-time logs
            socket.on('log_update', data => {
                if (Array.isArray(data.logs)) {
                    logsContainer.innerHTML = '';
                    data.logs.forEach(log => {
                        const logEntry = document.createElement('div');
                        logEntry.className = 'log-entry';
                        
                        // Set color based on log level
                        if (log.includes('ERROR') || log.includes('CRITICAL')) {
                            logEntry.classList.add('log-error');
                        } else if (log.includes('WARNING')) {
                            logEntry.classList.add('log-warning');
                        } else {
                            logEntry.classList.add('log-info');
                        }
                        
                        logEntry.textContent = log;
                        logsContainer.appendChild(logEntry);
                    });
                } else if (data.log) {
                    const logEntry = document.createElement('div');
                    logEntry.className = 'log-entry';
                    
                    // Set color based on log level
                    if (data.log.includes('ERROR') || data.log.includes('CRITICAL')) {
                        logEntry.classList.add('log-error');
                    } else if (data.log.includes('WARNING')) {
                        logEntry.classList.add('log-warning');
                    } else {
                        logEntry.classList.add('log-info');
                    }
                    
                    logEntry.textContent = data.log;
                    logsContainer.appendChild(logEntry);
                    logsContainer.scrollTop = logsContainer.scrollHeight;
                }
            });
            
            // Initial log load
            fetch('/api/logs')
                .then(response => response.json())
                .then(logs => {
                    logs.forEach(log => {
                        const logEntry = document.createElement('div');
                        logEntry.className = 'log-entry';
                        
                        // Set color based on log level
                        if (log.includes('ERROR') || log.includes('CRITICAL')) {
                            logEntry.classList.add('log-error');
                        } else if (log.includes('WARNING')) {
                            logEntry.classList.add('log-warning');
                        } else {
                            logEntry.classList.add('log-info');
                        }
                        
                        logEntry.textContent = log;
                        logsContainer.appendChild(logEntry);
                    });
                    logsContainer.scrollTop = logsContainer.scrollHeight;
                })
                .catch(error => console.error('Error loading logs:', error));
        }
        
        function loadFirewallStatus() {
            fetch('/api/firewall/status')
                .then(response => response.json())
                .then(data => {
                    const statusElement = document.getElementById('firewall-status');
                    if (data.active) {
                        statusElement.textContent = 'RapyDe Guard ON';
                        statusElement.style.color = 'green';
                    } else {
                        statusElement.textContent = 'RapyDe Guard OFF';
                        statusElement.style.color = 'red';
                    }
                })
                .catch(error => console.error('Error loading firewall status:', error));
        }
        
        function loadAdapters() {
            fetch('/api/adapters')
                .then(response => response.json())
                .then(adapters => {
                    const tbody = document.getElementById('adapters-tbody');
                    tbody.innerHTML = '';
                    
                    adapters.forEach(adapter => {
                        const row = document.createElement('tr');
                        
                        row.innerHTML = `
                            <td>${adapter}</td>
                            <td>
                                <button class="danger" onclick="removeAdapter('${adapter}')">Remove</button>
                            </td>
                        `;
                        
                        tbody.appendChild(row);
                    });
                })
                .catch(error => console.error('Error loading adapters:', error));
        }
        
        function loadAvailableAdapters() {
            fetch('/api/adapters/available')
                .then(response => response.json())
                .then(adapters => {
                    const select = document.getElementById('adapter-select');
                    select.innerHTML = '';
                    
                    adapters.forEach(adapter => {
                        const option = document.createElement('option');
                        option.value = adapter;
                        option.textContent = adapter;
                        select.appendChild(option);
                    });
                })
                .catch(error => console.error('Error loading available adapters:', error));
        }
        
        function loadInterfacesForRuleForm() {
            fetch('/api/adapters')
                .then(response => response.json())
                .then(adapters => {
                    const select = document.getElementById('interface');
                    // Keep the "All Interfaces" option
                    select.innerHTML = '<option value="">All Interfaces</option>';
                    
                    adapters.forEach(adapter => {
                        const option = document.createElement('option');
                        option.value = adapter;
                        option.textContent = adapter;
                        select.appendChild(option);
                    });
                })
                .catch(error => console.error('Error loading interfaces:', error));
        }
        
        // Action functions
        window.deleteRule = function(index) {
            if (confirm('Are you sure you want to delete this rule?')) {
                fetch(`/api/rules/${index}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => loadRules())
                .catch(error => console.error('Error deleting rule:', error));
            }
        };
        
        window.moveRule = function(index, direction) {
            fetch('/api/rules/reorder', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    index: index,
                    direction: direction
                })
            })
            .then(response => response.json())
            .then(data => loadRules())
            .catch(error => console.error('Error reordering rules:', error));
        };
        
        window.deleteUser = function(username) {
            if (confirm(`Are you sure you want to delete user ${username}?`)) {
                fetch(`/api/users/${username}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => loadUsers())
                .catch(error => console.error('Error deleting user:', error));
            }
        };
        
        window.changePassword = function(username) {
            document.getElementById('change-password-username').value = username;
            changePasswordModal.style.display = 'block';
        };
        
        window.removeAdapter = function(adapter) {
            if (confirm(`Are you sure you want to remove adapter ${adapter}?`)) {
                fetch(`/api/adapters/${adapter}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => loadAdapters())
                .catch(error => console.error('Error removing adapter:', error));
            }
        };
        
        // Load initial data
        loadRules();
    </script>
</body>
</html>
        ''')

def open_gui_mode():
    global flask_app, socketio, web_server_running
    
    if not web_server_running:
        # Create templates directory and HTML files
        create_templates_folder()
        
        # Create Flask app
        flask_app, socketio = create_flask_app()
        
        # Set up routes and socket handlers
        setup_web_gui(flask_app, socketio)
        
        # Start web server in a separate thread
        def run_server():
            socketio.run(flask_app, host='0.0.0.0', port=5000, debug=False)
        
        server_thread = threading.Thread(target=run_server)
        server_thread.daemon = True
        server_thread.start()
        
        web_server_running = True
        
        # Give the server a moment to start
        sleep(1)
        
        # Open web browser
        url = "http://localhost:5000"
        print(f"\n{GREEN}Opening RapyDe Guard Firewall GUI in web browser...{RESET}")
        print(f"If the browser doesn't open automatically, visit: {url}")
        webbrowser.open(url)
    else:
        print(f"\n{GREEN}RapyDe Guard Firewall GUI is already running at http://localhost:5000{RESET}")
        webbrowser.open("http://localhost:5000")

#########################           Welcome Notes          #########################    



welcome_art = r"""          __        __   _                                       
          \ \      / /__| | ___ ___  _ __ ___   ___              
           \ \ /\ / / _ \ |/ __/ _ \| '_ ` _ \ / _ \             
            \ V  V /  __/ | (_| (_) | | | | | |  __/             
 ____        \_/\_/ \___|_|\___\___/|_|_|_| |_|\___|           _ 
|  _ \ __ _ _ __  _   _|  _ \  ___   / ___|_   _  __ _ _ __ __| |
| |_) / _` | '_ \| | | | | | |/ _ \ | |  _| | | |/ _` | '__/ _` |
|  _ < (_| | |_) | |_| | |_| |  __/ | |_| | |_| | (_| | | | (_| |
|_| \_\__,_| .__/ \__, |____/ \___|  \____|\__,_|\__,_|_|  \__,_|
           |_|    |___/                                          
           
               COHNDNE241F-011 & COHNDNE241F-012
HND Bsc Hons Ethical Hacking & Network Security 2nd year undergraduate
           """

######################################          Say good bye          ######################################
goodbye_art = r"""
   ____                 _   ____               _ _ _ 
  / ___| ___   ___   __| | | __ ) _   _  ___  | | | |
 | |  _ / _ \ / _ \ / _` | |  _ \| | | |/ _ \ | | | |
 | |_| | (_) | (_) | (_| | | |_) | |_| |  __/ |_|_|_|
  \____|\___/ \___/ \__,_| |____/ \__, |\___| (_|_|_)
                                  |___/              

"""






# File to store run count
run_count_file = 'run_count.txt'

def read_run_count():
    if os.path.exists(run_count_file):
        with open(run_count_file, 'r') as f:
            try:
                return int(f.read().strip())
            except:
                return 0
    else:
        return 0

def write_run_count(count):
    with open(run_count_file, 'w') as f:
        f.write(str(count))

# ANSI color codes
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
RESET = '\033[0m'

# Main logic
count = read_run_count()
#color = RED if count % 2 == 0 else GREEN
if count % 6 == 0:
    color = RED
elif count % 6 == 1:
    color = GREEN
elif count % 6 == 2:
    color = YELLOW
elif count % 6 == 3:
    color = BLUE
elif count % 6 == 4:
    color = MAGENTA
else: color = CYAN
#print(color + welcome_art + RESET)
#write_run_count(count + 1)




def main_menu():




    while True:
        print(f"\n{GREEN}RapyDe Guard Firewall - Main Menu{RESET}")
        print("1 - Manage Rules")
        print("2 - System Security")
        print("3 - IDS/IPS Management")
        print("4 - System Logs")
        print("5 - Firewall Manage")
        print("6 - Network Manager")
        print("7 - Open in GUI Mode")
        print("8 - Exit")
        
        sel = input("Select: ")
        
        if sel == "1": manage_rules()
        elif sel == "2": system_security()
        elif sel == "3": ids_ips_management()
        elif sel == "4": show_logs()
        elif sel == "5": firewall_manage()
        elif sel == "6": network_manager()
        elif sel == "7": open_gui_mode()
        elif sel == "8":
            #print("Goodbye!")
            print(color + goodbye_art + RESET)
            write_run_count(count + 1)
            sys.exit(0)
        else:
            print(f"{RED}Invalid choice{RESET}")

if __name__ == "__main__":
    if os.geteuid() != 0:
        print(f"{RED}This program must be run as root!{RESET}")
        sys.exit(1)
        
    print(f"{CYAN}RapyDe Guard Firewall{RESET}")
    print(f"{YELLOW}Initializing...{RESET}")
    init_system()
    print(f"{GREEN}System initialized{RESET}")
        
    if authenticate():

        print(color + welcome_art + RESET)
        write_run_count(count + 1)
        print(f"{GREEN}Authentication successful{RESET}")
        main_menu()
